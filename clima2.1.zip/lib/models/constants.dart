import 'package:flutter/material.dart';

class Constants{
  final Color primaryColor = Color.fromARGB(255, 3, 82, 252);
  final Color secondaryColor = Color.fromARGB(255, 244, 236, 3);
}